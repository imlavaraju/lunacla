module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // Add all paths where Tailwind classes are used
  ],
  // ...other configurations
};
